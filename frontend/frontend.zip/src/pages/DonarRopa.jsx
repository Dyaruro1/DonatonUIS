import React from 'react';

function DonarRopa() {
  return <h2>Donar Ropa</h2>;
}

export default DonarRopa;
