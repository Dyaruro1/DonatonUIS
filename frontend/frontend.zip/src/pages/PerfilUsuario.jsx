import React from 'react';

function PerfilUsuario() {
  return <h2>Perfil de Usuario</h2>;
}

export default PerfilUsuario;
