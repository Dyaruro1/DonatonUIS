import React, { useEffect, useState, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import './FeedPrendas.css';
import { donatonService } from '../services/api';

function FeedPrendas() {
  const [prendas, setPrendas] = useState([]);
  const [loading, setLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [skip, setSkip] = useState(0);
  const limit = 12;
  const loader = useRef(null);
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(true); 
  const handleSidebarNav = (route) => {
    navigate(route);
  };

  // Scroll infinito
  const loadMore = useCallback(async () => {
    if (loading || !hasMore) return;
    setLoading(true);
    try {
      const resp = await donatonService.getPrendasDisponibles(skip, limit);
      if (resp.data.length < limit) setHasMore(false);
      setPrendas(prev => [...prev, ...resp.data]);
      setSkip(prev => prev + limit);
    } catch (e) {
      setHasMore(false);
    } finally {
      setLoading(false);
    }
  }, [skip, loading, hasMore]);

  useEffect(() => {
    loadMore();
    // eslint-disable-next-line
  }, []);

  // Observer para scroll infinito
  useEffect(() => {
    if (!loader.current) return;
    const observer = new window.IntersectionObserver(entries => {
      if (entries[0].isIntersecting && hasMore && !loading) {
        loadMore();
      }
    }, { threshold: 1 });
    observer.observe(loader.current);
    return () => observer.disconnect();
  }, [loader, loadMore, hasMore, loading]);


useEffect(() => {
  console.log("sidebarOpen es:", sidebarOpen);
}, [sidebarOpen]);

return (
  <div className={`feed-root ${sidebarOpen ? 'sidebar-open' : ''}`}>
    {/* Menú lateral desplegable */}
    <div className={`custom-sidebar ${sidebarOpen ? 'open' : ''}`}>
      <div className="sidebar-toggle" onClick={() => setSidebarOpen(!sidebarOpen)}>
        <span className="sidebar-toggle-bar"></span>
        <span className="sidebar-toggle-bar"></span>
      </div>
      <nav className="custom-sidebar-nav sidebar-tabs">
        <button className={`custom-sidebar-tab${window.location.pathname === '/feed' ? ' custom-sidebar-tab-active' : ''}`} onClick={() => handleSidebarNav('/feed')}>
          <span className="custom-sidebar-icon">🧺</span>
          <span className={`custom-sidebar-label ${sidebarOpen ? 'visible' : 'hidden'}`}>Prendas</span>
        </button>
        <button className={`custom-sidebar-tab${window.location.pathname === '/donar' ? ' custom-sidebar-tab-active' : ''}`} onClick={() => handleSidebarNav('/donar')}>
          <span className="custom-sidebar-icon">🤲</span>
          <span className={`custom-sidebar-label ${sidebarOpen ? 'visible' : 'hidden'}`}>Donar</span>
        </button>
        <button className={`custom-sidebar-tab${window.location.pathname === '/perfil' ? ' custom-sidebar-tab-active' : ''}`} onClick={() => handleSidebarNav('/perfil')}>
          <span className="custom-sidebar-icon">👤</span>
          <span className={`custom-sidebar-label ${sidebarOpen ? 'visible' : 'hidden'}`}>Perfil</span>
        </button>
        <button className={`custom-sidebar-tab${window.location.pathname === '/ajustes' ? ' custom-sidebar-tab-active' : ''}`} onClick={() => handleSidebarNav('/ajustes')}>
          <span className="custom-sidebar-icon">⚙️</span>
          <span className={`custom-sidebar-label ${sidebarOpen ? 'visible' : 'hidden'}`}>Configuración</span>
        </button>
      </nav>
    </div>

    {/* CONTENIDO PRINCIPAL */}
    <main className="feed-main">
      <header className="feed-header">
        <input className="feed-search" placeholder="¿Qué estás buscando?" />
        <select className="feed-filter">
          <option>Filtrar por...</option>
          <option value="talla">Talla</option>
          <option value="sexo">Sexo</option>
          <option value="uso">Uso</option>
        </select>
        <div className="feed-user-actions">
          <span className="feed-bell"><i className="fa fa-bell"></i></span>
          <span className="feed-avatar"><img src="/logo-pequeno.svg" alt="avatar" /></span>
        </div>
      </header>
      <div className="feed-publicaciones-row" style={{ justifyContent: 'flex-start', gap: '2.5rem' }}>
        <span className="feed-publicaciones-title" style={{ marginRight: '2.5rem' }}>Prendas disponibles</span>
        <div className="feed-publicaciones-tabs">
          <span className="feed-tab feed-tab-active">Disponibles</span>
          <span className="feed-tab">Mis publicaciones</span>
        </div>
      </div>
      <section className="feed-grid">
        {prendas.map((prenda, idx) => (
          <div className="feed-card" key={prenda.id || idx}>
            <div className="feed-card-img">
              <img src={prenda.imagen_url || '/fondo-uis.jpg'} alt={prenda.nombre} />
            </div>
            <div className="feed-card-body">
              <div className="feed-card-title">{prenda.nombre}</div>
              <div className="feed-card-info">
                <div>Talla <span>{prenda.talla}</span></div>
                <div>Sexo <span>{prenda.sexo}</span></div>
                <div>Uso <span>{prenda.uso}</span></div>
              </div>
              <button className="feed-card-btn">Detalles de la prenda</button>
            </div>
          </div>
        ))}
      </section>
      <div ref={loader} style={{ height: 40 }}></div>
      {loading && <div className="feed-loading">Cargando...</div>}
      {!hasMore && prendas.length === 0 && <div className="feed-empty">No hay prendas disponibles.</div>}
    </main>
  </div>
);

}

export default FeedPrendas;
