import React from 'react';

function SolicitarRopa() {
  return <h2>Solicitar Ropa</h2>;
}

export default SolicitarRopa;
